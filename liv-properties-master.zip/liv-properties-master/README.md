Repo containing the code for LIV Squared Properties frontend.

LIV Squared Properties in a real estate agency in UAE.

run outside of github:

1 in next.config.js remove basePath

2 replace "" with nothing

3 `yarn build && npx serve@latest out`
