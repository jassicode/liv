'use client';

export const Year = () => <span id='year'>{new Date().getFullYear()}</span>;
